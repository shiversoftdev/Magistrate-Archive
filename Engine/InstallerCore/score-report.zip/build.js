var data;

var request = new XMLHttpRequest();
request.open('GET', 'data.json', true);

request.onload = function() {
  if (this.status >= 200 && this.status < 400) {
    data = JSON.parse(this.response);
  } else {
    console.log("Error..?")
  }
};

request.onerror = function() {
  console.log("Error..?")
};

request.send();

// Finish converting away from jQuery

$(function() {
    $.getJSON( "data.json", (data) => {
      $(".name").text(data.scoring_info.name);
      $(".start_time").text(data.scoring_info.start_time);
      $(".running_time").text(data.scoring_info.running_time);
      $(".checks_count").text(data.scoring_info.checks_complete + "/" + data.scoring_info.checks_total + " checks complete.");

      var checks = [];
      var points = 0;
      $.each(data.checks, function( key, val ) {
        // checks.push( "<div class='check'><div class='check-id'>" + key + "</div><div class='check-points'>" + val.points + "</div><div class='check-desc'>" + val.desc + "</div></div>");
        checks.push("<div class='check'><div class='box'><div class='label'>Check ID</div><div class='check-id'>" + key + "</div></div><div class='box'><div class='label'>Check Points</div><div class='check-points'>" + val.points + "</div></div><div class='box'><div class='label'>Check Description</div><div class='check-desc'>" + val.description + "</div></div></div>");
        points += val.points;
        console.log(points);
      });

      $("#checks").html(checks.join(''));
      $(".points").text(points);
    });
})